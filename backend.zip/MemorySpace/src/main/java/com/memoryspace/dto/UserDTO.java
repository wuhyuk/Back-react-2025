package com.memoryspace.dto;

public class UserDTO {
    private long id;
    private String username;
    private String passwordHash;
    private String nickname;
    private String email;
    private String liveIn;

    public UserDTO(long id, String username, String passwordHash, String nickname,
                   String email, String liveIn) {
        this.id = id;
        this.username = username;
        this.passwordHash = passwordHash;
        this.nickname = nickname;
        this.email = email;
        this.liveIn = liveIn;
    }

    public void setId(long id) {
		this.id = id;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setLiveIn(String liveIn) {
		this.liveIn = liveIn;
	}

	public long getId() { return id; }
    public String getUsername() { return username; }
    public String getPasswordHash() { return passwordHash; }
    public String getNickname() { return nickname; }
    public String getEmail() { return email; }
    public String getLiveIn() { return liveIn; }
}
