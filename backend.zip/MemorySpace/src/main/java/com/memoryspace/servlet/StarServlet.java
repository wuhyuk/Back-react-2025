package com.memoryspace.servlet;

import com.memoryspace.dao.StarDAO;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/api/stars")
public class StarServlet extends HttpServlet {
    private StarDAO starDAO;

    @Override
    public void init() { starDAO = new StarDAO(); }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json; charset=UTF-8");

        // 로그인된 userId 우선 사용 (세션에 저장되어 있어야 함)
        HttpSession session = req.getSession(false);
        Long userId = null;
        if (session != null && session.getAttribute("userId") != null) {
            userId = (Long) session.getAttribute("userId");
        }

        // 프론트가 userId를 전달한 경우 (세션이 없을 때)
        if (userId == null) {
            String uid = req.getParameter("userId");
            if (uid != null) userId = Long.parseLong(uid);
        }

        String name = req.getParameter("name");

        boolean success = false;
        if (userId == null) {
            // 인증 필요
            try (PrintWriter out = resp.getWriter()) {
                out.write("{\"success\": false, \"message\": \"Login required\"}");
                return;
            }
        } else if (name == null || name.trim().isEmpty()) {
            try (PrintWriter out = resp.getWriter()) {
                out.write("{\"success\": false, \"message\": \"Missing star name\"}");
                return;
            }
        } else {
            success = starDAO.createStar(userId, name);
        }

        try (PrintWriter out = resp.getWriter()) {
            out.write("{\"success\": " + success + "}");
        }
    }

    // GET: user의 stars 목록 조회 (세션 우선)
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json; charset=UTF-8");

        HttpSession session = req.getSession(false);
        Long userId = null;
        if (session != null && session.getAttribute("userId") != null) {
            userId = (Long) session.getAttribute("userId");
        } else {
            String uid = req.getParameter("userId");
            if (uid != null) userId = Long.parseLong(uid);
        }

        try (PrintWriter out = resp.getWriter()) {
            if (userId == null) {
                out.write("[]");
                return;
            }

            StarDAO dao = new StarDAO();
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            boolean first = true;
            for (var s : dao.getStarsByUser(userId)) {
                if (!first) sb.append(",");
                sb.append("{\"id\":").append(s.getId()).append(",\"userId\":").append(s.getUserId())
                  .append(",\"name\":\"").append(escapeJson(s.getName())).append("\"}");
                first = false;
            }
            sb.append("]");
            out.write(sb.toString());
        }
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\"", "\\\"");
    }
}
