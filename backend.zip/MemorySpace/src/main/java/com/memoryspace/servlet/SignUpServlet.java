package com.memoryspace.servlet;

import com.memoryspace.dao.UserDAO;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/api/signup")
public class SignUpServlet extends HttpServlet {
    private UserDAO userDAO;

    @Override
    public void init() {
        userDAO = new UserDAO();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException {

        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json; charset=UTF-8");

        // 프론트에서 어떤 키로 보낼지 다를 수 있으니 여러 이름을 체크
        String username = firstNonNull(req.getParameter("username"), req.getParameter("id"));
        String password = firstNonNull(req.getParameter("password"), req.getParameter("pw"));
        String nickname = firstNonNull(req.getParameter("nickname"), req.getParameter("name"));
        String email = req.getParameter("email");
        String liveIn = firstNonNull(req.getParameter("liveIn"), req.getParameter("region"));

        boolean success = false;
        String message = null;

        if (username == null || password == null || nickname == null || email == null) {
            message = "Missing required fields.";
        } else if (userDAO.isUserIdExists(username)) {
            message = "This ID is already in use.";
        } else {
            success = userDAO.createUser(username, password, nickname, email, liveIn);
            if (!success) message = "Failed to sign up.";
        }

        // application scope: 저장 (예: 최근 가입자 이름, 총 가입수)
        if (success) {
            ServletContext ctx = getServletContext();
            ctx.setAttribute("lastSignedUpUser", username);
            Integer total = (Integer) ctx.getAttribute("totalSignups");
            if (total == null) total = 0;
            ctx.setAttribute("totalSignups", total + 1);
        }

        try (PrintWriter out = resp.getWriter()) {
            if (success) {
                out.write("{\"success\": true}");
            } else {
                if (message == null) message = "Unknown error";
                message = message.replace("\"", "\\\"");
                out.write("{\"success\": false, \"message\": \"" + message + "\"}");
            }
        }
    }

    private String firstNonNull(String... arr) {
        for (String s : arr) if (s != null && !s.isEmpty()) return s;
        return null;
    }
}
