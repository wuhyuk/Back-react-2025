package com.memoryspace.servlet;

import com.memoryspace.dao.UserDAO;
import com.memoryspace.dto.UserDTO;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/api/login")
public class LoginServlet extends HttpServlet {
    private UserDAO userDAO;

    @Override
    public void init() { userDAO = new UserDAO(); }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json; charset=UTF-8");

        String username = firstNonNull(req.getParameter("username"), req.getParameter("id"));
        String password = firstNonNull(req.getParameter("password"), req.getParameter("pw"));

        try (PrintWriter out = resp.getWriter()) {
            if (username == null || password == null) {
                out.write("{\"success\": false, \"message\": \"Missing credentials\"}");
                return;
            }

            UserDTO user = userDAO.login(username, password);
            if (user == null) {
                out.write("{\"success\": false, \"message\": \"Invalid username or password\"}");
                return;
            }

            // 로그인 성공 -> 세션에 사용자 정보 저장 (session 영역)
            HttpSession session = req.getSession(true);
            session.setAttribute("userId", user.getId());
            session.setAttribute("username", user.getUsername());
            session.setAttribute("nickname", user.getNickname());

            // 관리자 분기 (프론트에서 처리하려면 role 리턴)
            if ("manager".equals(user.getUsername())) {
                // 프론트/서버 쪽에서 관리자 페이지 이동 처리 필요
                out.write("{\"success\": true, \"role\": \"manager\", \"userId\": " + user.getId() + "}");
                return;
            }

            out.write("{\"success\": true, \"role\": \"user\", \"userId\": " + user.getId() + "}");
        }
    }

    private String firstNonNull(String... arr) {
        for (String s : arr) if (s != null && !s.isEmpty()) return s;
        return null;
    }
}
