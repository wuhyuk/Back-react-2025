package com.memoryspace.dao;

import com.memoryspace.db.JdbcConnect;
import com.memoryspace.dto.UserDTO;

import java.sql.*;
import java.security.MessageDigest;

public class UserDAO {

    private String hashPassword(String password) {
        if (password == null) return null;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(password.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean isUserIdExists(String username) {
        String sql = "SELECT id FROM users WHERE username = ?";
        try (Connection conn = JdbcConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }

    public boolean createUser(String username, String password, String nickname,
                              String email, String liveIn) {
        String sql = "INSERT INTO users(username, passwordHash, nickname, email, liveIn) VALUES (?,?,?,?,?)";
        try (Connection conn = JdbcConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, hashPassword(password));
            ps.setString(3, nickname);
            ps.setString(4, email);
            ps.setString(5, liveIn);
            return ps.executeUpdate() == 1;
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }

    public UserDTO login(String username, String password) {
        String sql = "SELECT * FROM users WHERE username = ? AND passwordHash = ?";
        try (Connection conn = JdbcConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, hashPassword(password));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new UserDTO(
                    rs.getLong("id"),
                    rs.getString("username"),
                    rs.getString("passwordHash"),
                    rs.getString("nickname"),
                    rs.getString("email"),
                    rs.getString("liveIn")
                );
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }
}
