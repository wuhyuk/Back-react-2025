package com.memoryspace.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class JdbcConnect {
    private static final String URL = "jdbc:mysql://localhost:3306/memoryspace?serverTimezone=UTC&characterEncoding=UTF-8";
    private static final String USER = "root";     // 환경에 맞게 변경
    private static final String PASSWORD = "1234"; // 환경에 맞게 변경

    public static Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
