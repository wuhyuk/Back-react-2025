package com.memoryspace.servlet;

import com.memoryspace.dao.PlanetDAO;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/api/planets")
public class PlanetServlet extends HttpServlet {
    private PlanetDAO planetDAO;

    @Override
    public void init() { planetDAO = new PlanetDAO(); }

    // 생성
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json; charset=UTF-8");

        String starIdParam = req.getParameter("starId");
        String name = req.getParameter("name");
        Long starId = (starIdParam != null) ? Long.parseLong(starIdParam) : null;

        if (starId == null || name == null || name.trim().isEmpty()) {
            try (PrintWriter out = resp.getWriter()) {
                out.write("{\"success\": false, \"message\": \"Missing parameters\"}");
            }
            return;
        }

        boolean success = planetDAO.createPlanet(starId, name);
        try (PrintWriter out = resp.getWriter()) {
            out.write("{\"success\": " + success + "}");
        }
    }

    // 삭제 (soft delete)
    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json; charset=UTF-8");

        String planetIdParam = req.getParameter("planetId");
        if (planetIdParam == null) {
            try (PrintWriter out = resp.getWriter()) {
                out.write("{\"success\": false, \"message\": \"Missing planetId\"}");
            }
            return;
        }

        long planetId = Long.parseLong(planetIdParam);
        boolean success = planetDAO.softDeletePlanet(planetId);

        try (PrintWriter out = resp.getWriter()) {
            out.write("{\"success\": " + success + "}");
        }
    }

    // GET: 특정 star의 planets 조회
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json; charset=UTF-8");

        String starIdParam = req.getParameter("starId");
        if (starIdParam == null) {
            try (PrintWriter out = resp.getWriter()) {
                out.write("[]");
            }
            return;
        }

        long starId = Long.parseLong(starIdParam);
        var list = planetDAO.getPlanets(starId);

        StringBuilder sb = new StringBuilder();
        sb.append("[");
        boolean first = true;
        for (var p : list) {
            if (!first) sb.append(",");
            sb.append("{\"id\":").append(p.getId()).append(",\"starId\":").append(p.getStarId())
              .append(",\"name\":\"").append(escapeJson(p.getName())).append("\",\"isDeleted\":")
              .append(p.isDeleted() ? 1 : 0).append("}");
            first = false;
        }
        sb.append("]");

        try (PrintWriter out = resp.getWriter()) {
            out.write(sb.toString());
        }
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\"", "\\\"");
    }
}
