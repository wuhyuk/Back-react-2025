package com.memoryspace.dao;

import com.memoryspace.db.JdbcConnect;
import com.memoryspace.dto.PlanetDTO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PlanetDAO {

    public List<PlanetDTO> getPlanets(long starId) {
        List<PlanetDTO> list = new ArrayList<>();
        String sql = "SELECT * FROM planets WHERE star_id = ? AND is_deleted = 0";
        try (Connection conn = JdbcConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, starId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new PlanetDTO(
                    rs.getLong("id"),
                    rs.getLong("star_id"),
                    rs.getString("name"),
                    rs.getInt("is_deleted") == 1
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public boolean createPlanet(long starId, String name) {
        String sql = "INSERT INTO planets(star_id, name) VALUES (?, ?)";
        try (Connection conn = JdbcConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, starId);
            ps.setString(2, name);
            return ps.executeUpdate() == 1;
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }

    public boolean softDeletePlanet(long planetId) {
        String sql = "UPDATE planets SET is_deleted = 1 WHERE id = ?";
        try (Connection conn = JdbcConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, planetId);
            return ps.executeUpdate() == 1;
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }
}
