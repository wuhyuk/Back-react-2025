package com.memoryspace.dto;

public class StarDTO {
    private long id;
    private long userId;
    private String name;

    public StarDTO(long id, long userId, String name) {
        this.id = id;
        this.userId = userId;
        this.name = name;
    }

    public long getId() { return id; }
    public long getUserId() { return userId; }
    public String getName() { return name; }
}
