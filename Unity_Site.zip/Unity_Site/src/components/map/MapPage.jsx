import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import './MapPage.css';

// 🔹 마커 아이콘 이미지 깨짐 방지 코드 (DivIcon 사용 시 불필요하나, 기존 아이콘 사용 대비 유지)
import iconMarker from 'leaflet/dist/images/marker-icon.png';
import iconRetina from 'leaflet/dist/images/marker-icon-2x.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

const MapPage = () => {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);

  // 🔹 1. 원하는 지역의 데이터 (숫자 값 추가)
  const locations = [
    { id: 1, name: "<b>서울 (Seoul)</b><br>Korea", lat: 37.5665, lng: 126.9780, value: 50 },
    { id: 2, name: "<b>뉴욕 (New York)</b><br>USA", lat: 40.7128, lng: -74.0060, value: 120 },
    { id: 3, name: "<b>런던 (London)</b><br>UK", lat: 51.5074, lng: -0.1278, value: 80 },
    { id: 4, name: "<b>시드니 (Sydney)</b><br>Australia", lat: -33.8688, lng: 151.2093, value: 30 },
    { id: 5, name: "<b>도쿄 (Tokyo)</b><br>Japan", lat: 35.6762, lng: 139.6503, value: 150 },
    { id: 6, name: "<b>파리 (Paris)</b><br>France", lat: 48.8566, lng: 2.3522, value: 95 },
    { id: 7, name: "<b>상파울루 (Sao Paulo)</b><br>Brazil", lat: -23.5505, lng: -46.6333, value: 65 },
  ];

  // 🔹 파란색 계열 색상 배열
  const blueColors = [
    '#3366FF', '#007FFF', '#00BFFF', '#1E90FF', '#6495ED',
    '#4169E1', '#0000FF', '#0000CD', '#00008B', '#00BFF7'
  ];

  // 🔹 무작위 색상 선택 함수
  const getRandomBlue = () => {
    return blueColors[Math.floor(Math.random() * blueColors.length)];
  };

  useEffect(() => {
    if (mapInstanceRef.current) return;

    // --- 기본 아이콘 설정 (DivIcon 사용 시 불필요하나, 기존 L.marker 대비 유지) ---
    const DefaultIcon = L.icon({
        iconUrl: iconMarker,
        iconRetinaUrl: iconRetina,
        shadowUrl: iconShadow,
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowSize: [41, 41]
    });
    L.Marker.prototype.options.icon = DefaultIcon;

    // --- 지도 범위 제한 ---
    const corner1 = L.latLng(-85, -180);
    const corner2 = L.latLng(85, 180);
    const bounds = L.latLngBounds(corner1, corner2);

    // --- 지도 생성 ---
    const map = L.map(mapContainerRef.current, {
      center: [20, 0],
      zoom: 3,
      minZoom: 3,
      maxBounds: bounds,
      maxBoundsViscosity: 1.0
    });

    mapInstanceRef.current = map;

    // --- 타일 레이어 (밝은 테마) ---
    L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; OpenStreetMap &copy; CARTO',
      subdomains: 'abcd',
      maxZoom: 19,
      noWrap: true,
      bounds: bounds
    }).addTo(map);

    L.control.scale({ imperial: true, metric: true }).addTo(map);

    // 🔹 2. 각 위치에 CircleMarker와 숫자 아이콘 표시
    locations.forEach((loc) => {
      // 🔹 값에 따른 반지름 (크기) 계산
      // 최소 크기 + (값 / 최대 값) * (최대 증가 크기)
      const baseRadius = 20; // 기본 원 크기
      const radiusMultiplier = 0.08; // 숫자가 커질 때 반지름이 얼마나 더 커질지
      const maxPossibleValue = 200; // 예상되는 최대 value 값 (이 값 기준으로 크기 조절)
      const calculatedRadius = baseRadius + (loc.value / maxPossibleValue) * baseRadius * radiusMultiplier;

      // 🔹 값에 따른 투명도 계산 (숫자가 클수록 더 투명하게)
      // 최소 투명도 - (값 / 최대 값) * (최대 감소 투명도)
      const baseOpacity = 0.9; // 기본 투명도
      const opacityReductionFactor = 0.5; // 투명도 감소 폭
      const calculatedOpacity = Math.max(0.3, baseOpacity - (loc.value / maxPossibleValue) * opacityReductionFactor); // 최소 0.3 투명도 유지

      const randomBlue = getRandomBlue();

      // 🔹 CircleMarker (원) 추가
      L.circleMarker([loc.lat, loc.lng], {
        color: randomBlue,      // 원 테두리 색상
        weight: 2,             // 테두리 두께
        fillColor: randomBlue,  // 원 채우기 색상
        fillOpacity: calculatedOpacity, // 계산된 투명도
        radius: calculatedRadius // 계산된 반지름
      })
      .addTo(map)
      .bindPopup(loc.name);

      // 🔹 DivIcon (숫자) 추가
      const numberIcon = L.divIcon({
        className: 'number-icon', // CSS에서 스타일링할 클래스
        html: `<div class="number-circle" style="color: white; font-weight: bold; font-size: 12px;">${loc.value}</div>`,
        iconSize: [20, 20], // 아이콘 크기
        iconAnchor: [10, 10] // 아이콘의 중심점 (원의 중심과 일치시키기 위함)
      });

      L.marker([loc.lat, loc.lng], { icon: numberIcon }).addTo(map);
    });

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []); // 🔹 locations가 변경될 수 있다면 의존성 배열에 추가

  return (
    <div className="map-page-container">
      <div id="map" ref={mapContainerRef}></div>
    </div>
  );
};

export default MapPage;