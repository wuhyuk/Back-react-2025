// src/components/main/Main.jsx
import React, { useState, useCallback, useEffect } from "react";
import "./Main.css";

import Header from "../header/Header";
import Login from "../signIn/Login";
import SignUp from "../signUp/SignUp";
import SpaceBackground from "../background/SpaceBackground";
import StarBackground from "../star/StarBackground";
import M_Main from "../manager/M_Main";
import Introduction from "../etcView/Introduction";
import Tutorial from "../etcView/Tutorial";
import Example from "../etcView/Example";
import Inquiries from "../etcView/Inquiries";
import MyPage from "../myPage/MyPage";
import MyPassword from "../myPage/MyPassword";
import MapPage from "../map/MapPage";

const CONTEXT_PATH = "/MemorySpace";
const API_BASE = `${CONTEXT_PATH}/api`;

const stripContextPath = (pathname) => {
  if (!pathname.startsWith(CONTEXT_PATH)) return pathname || "/";
  let stripped = pathname.slice(CONTEXT_PATH.length);
  if (stripped === "" || stripped === "/" || stripped === "/index.html") {
    return "/";
  }
  return stripped.startsWith("/") ? stripped : `/${stripped}`;
};

const ManagerPage = ({ nickname, onLogout }) => {
  return <M_Main nickname={nickname} onLogout={onLogout} />;
};

const Main = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [nickname, setNickname] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);

  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  const initialPath = stripContextPath(window.location.pathname || "/");
  const [currentPage, setCurrentPage] = useState(initialPath);

  const isMapPage = currentPage === "/map";

  const handleOpenLogin = () => setIsLoginModalOpen(true);
  const handleCloseLogin = () => setIsLoginModalOpen(false);

  const handleLoginSuccess = (data) => {
    const displayName = data.nickname || data.userId || "";
    const adminFlag = data.role === "ADMIN";

    setIsLoggedIn(true);
    setNickname(displayName);
    setIsAdmin(adminFlag);

    if (adminFlag) {
      navigate("/manager");
    } else {
      navigate("/");
    }
  };

  const handleLogout = async () => {
    try {
      await fetch(`${API_BASE}/logout`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      });
    } catch (e) {
      console.error("로그아웃 요청 실패:", e);
    } finally {
      setIsLoggedIn(false);
      setNickname("");
      setIsAdmin(false);
      setIsLoginModalOpen(false);

      const logicalPath = "/";
      const fullPath = `${CONTEXT_PATH}/index.html`;
      window.history.pushState({}, "", fullPath);
      setCurrentPage(logicalPath);
    }
  };

  useEffect(() => {
    const checkAuth = async () => {
      const logicalPathNow = stripContextPath(
        window.location.pathname || "/"
      );

      try {
        const res = await fetch(`${API_BASE}/auth/me`, {
          method: "GET",
          headers: { Accept: "application/json" },
        });

        if (!res.ok) {
          setIsLoggedIn(false);
          setNickname("");
          setIsAdmin(false);

          if (
            logicalPathNow === "/manager" ||
            logicalPathNow === "/map" ||
            logicalPathNow === "/my-space"
          ) {
            const fullPath = `${CONTEXT_PATH}/index.html`;
            window.history.replaceState({}, "", fullPath);
            setCurrentPage("/");
          } else {
            setCurrentPage(logicalPathNow);
          }
          return;
        }

        const data = await res.json();

        if (data.loggedIn) {
          const adminFlag = data.role === "ADMIN";

          setIsLoggedIn(true);
          setNickname(data.nickname || data.userId || "");
          setIsAdmin(adminFlag);

          if (logicalPathNow === "/manager" && !adminFlag) {
            const fullPath = `${CONTEXT_PATH}/index.html`;
            window.history.replaceState({}, "", fullPath);
            setCurrentPage("/");
          } else {
            setCurrentPage(logicalPathNow);
          }
        } else {
          setIsLoggedIn(false);
          setNickname("");
          setIsAdmin(false);

          if (
            logicalPathNow === "/manager" ||
            logicalPathNow === "/map" ||
            logicalPathNow === "/my-space"
          ) {
            const fullPath = `${CONTEXT_PATH}/index.html`;
            window.history.replaceState({}, "", fullPath);
            setCurrentPage("/");
          } else {
            setCurrentPage(logicalPathNow);
          }
        }
      } catch (e) {
        console.error("로그인 상태 확인 실패:", e);
        setIsLoggedIn(false);
        setNickname("");
        setIsAdmin(false);

        if (
          logicalPathNow === "/manager" ||
          logicalPathNow === "/map" ||
          logicalPathNow === "/my-space"
        ) {
          const fullPath = `${CONTEXT_PATH}/index.html`;
          window.history.replaceState({}, "", fullPath);
          setCurrentPage("/");
        } else {
          setCurrentPage(logicalPathNow);
        }
      }
    };

    checkAuth();
  }, []);

  const navigate = useCallback((path, options = {}) => {
    const logicalPath = path.startsWith("/") ? path : `/${path}`;
    const fullPath =
      logicalPath === "/"
        ? `${CONTEXT_PATH}/index.html`
        : `${CONTEXT_PATH}${logicalPath}`;

    window.history.pushState({}, "", fullPath);
    setCurrentPage(logicalPath);

    if (options.openLogin) setIsLoginModalOpen(true);
    else setIsLoginModalOpen(false);
  }, []);

  useEffect(() => {
    const handlePopState = () => {
      const pathname = stripContextPath(window.location.pathname);

      if (
        (pathname === "/manager" && !isAdmin) ||
        (pathname === "/map" && !isLoggedIn) ||
        (pathname === "/my-space" && !isLoggedIn)
      ) {
        const fullPath = `${CONTEXT_PATH}/index.html`;
        window.history.replaceState({}, "", fullPath);
        setCurrentPage("/");
      } else {
        setCurrentPage(pathname);
      }

      setIsLoginModalOpen(false);
    };

    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, [isAdmin, isLoggedIn]);

  const renderContent = () => {
    switch (currentPage) {
      case "/signup":
        return <SignUp navigate={navigate} />;

      case "/manager":
        return (
          <ManagerPage
            nickname={nickname}
            onLogout={handleLogout}
          />
        );

      case "/map":
        if (!isLoggedIn) {
          // 새로고침 시에는 로그인 창을 띄우지 않고 홈으로만 이동
          navigate("/");
          return null;
        }
        return <MapPage />;

      // ⭐ My Space 라우트
      case "/my-space":
        if (!isLoggedIn) {
          // 새로고침 시에는 로그인 창을 띄우지 않고 홈으로만 이동
          navigate("/");
          return null;
        }
        return (
          <main className="main-wrapper">
            <StarBackground navigate={navigate} />
          </main>
        );

      case "/introduction":
        return <Introduction />;

      case "/tutorial":
        return <Tutorial />;

      case "/example":
        return <Example />;

      case "/inquiries":
        return <Inquiries />;

      case "/mypage":
        if (!isLoggedIn) {
          // 새로고침 시에는 로그인 창을 띄우지 않고 홈으로만 이동
          navigate("/");
          return null;
        }
        return (
          <MyPage
            navigate={navigate}
            onLogout={handleLogout}
            isLoggedIn={isLoggedIn}
            nickname={nickname}
          />
        );

      case "/mypassword":
        if (!isLoggedIn) {
          // 새로고침 시에는 로그인 창을 띄우지 않고 홈으로만 이동
          navigate("/");
          return null;
        }
        return (
          <MyPassword
            navigate={navigate}
            onLogout={handleLogout}
          />
        );

      case "/":
      default:
        return (
          <main className="main-wrapper">
            <SpaceBackground navigate={navigate} />
          </main>
        );
    }
  };

  return (
    <div className="app-root">
      {currentPage !== "/manager" && (
        <Header
          onLoginClick={handleOpenLogin}
          navigate={navigate}
          isLoggedIn={isLoggedIn}
          nickname={nickname}
          onLogout={handleLogout}
          isMapPage={isMapPage}
        />
      )}

      {renderContent()}

      <Login
        isOpen={isLoginModalOpen}
        onClose={handleCloseLogin}
        navigate={navigate}
        onLoginSuccess={handleLoginSuccess}
      />
    </div>
  );
};

export default Main;