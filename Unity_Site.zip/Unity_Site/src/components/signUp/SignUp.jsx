// src/components/SignUp.jsx
import React, { useState } from "react";
import "./SignUp.css";
import BlackHole from "../blackHelo/BlackHole";

const CONTEXT_PATH = "/MemorySpace";
const API_BASE = `${CONTEXT_PATH}/api`;

const SignUp = ({ navigate }) => {
  // 하나의 객체로 폼 상태 관리
  const [form, setForm] = useState({
    id: "",
    password: "",
    name: "",
    emailId: "",
    emailDomain: "",
    region: "",
  });

  // 이메일 도메인 선택 옵션
  const domainOptions = [
    "ENTER MANUALLY",
    "gmail.com",
    "naver.com",
    "daum.net",
    "hanmail.net",
    "kakao.com",
  ];

  // 지역 선택 옵션
  const regionOptions = [
    "서울",
    "경기도",
    "인천",
    "강원도",
    "충청북도",
    "충청남도",
    "경상북도",
    "경상남도",
    "전라북도",
    "전라남도",
    "제주도",
  ];

  // 공통 change 핸들러
  const handleChange = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  // 도메인 셀렉트 변경
  const handleDomainChange = (e) => {
    const selectedDomain = e.target.value;
    if (selectedDomain === "ENTER MANUALLY") {
      handleChange("emailDomain", "");
    } else {
      handleChange("emailDomain", selectedDomain);
    }
  };

  // 실제 회원가입 서블릿 호출
  const handleSubmit = async (e) => {
    e.preventDefault();

    const fullEmail = `${form.emailId}@${form.emailDomain}`;

    try {
      const response = await fetch(`${API_BASE}/signup`, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        },
        body: new URLSearchParams({
          id: form.id,
          password: form.password,
          name: form.name,
          email: fullEmail,
          region: form.region,
        }).toString(),
      });

      if (!response.ok) throw new Error("Server error");

      const data = await response.json();

      if (data.success) {
        alert("회원가입이 완료되었습니다. 이제 로그인해 주세요.");
        if (navigate) {
          // 메인으로 이동 + 로그인 모달 열기
          navigate("/", { openLogin: true });
        }
      } else {
        alert(data.message || "회원가입에 실패했습니다.");
      }
    } catch (err) {
      console.error("회원가입 요청 실패:", err);
      alert("서버 오류가 발생했습니다. 잠시 후 다시 시도해주세요.");
    }
  };

  // 일반 인풋 필드 정의 (map으로 렌더링)
  const inputFields = [
    {
      key: "id",
      label: "ID",
      type: "text",
      placeholder: "Please enter your username",
    },
    {
      key: "password",
      label: "PASSWORD",
      type: "password",
      placeholder: "Please enter your password",
    },
    {
      key: "name",
      label: "NICKNAME",
      type: "text",
      placeholder: "Please enter your nickname",
    },
  ];

  return (
    <div className="signup-page-root scrollable">
      <BlackHole />

      <div className="signup-page-container">
        <div className="signup-form-box">
          <h2>Sign Up</h2>
          <form onSubmit={handleSubmit}>
            {/* 공통 인풋 필드 */}
            {inputFields.map(({ key, label, type, placeholder }) => (
              <div className="form-group" key={key}>
                <label htmlFor={`signup-${key}`}>{label}</label>
                <input
                  type={type}
                  id={`signup-${key}`}
                  value={form[key]}
                  onChange={(e) => handleChange(key, e.target.value)}
                  required
                  placeholder={placeholder}
                />
              </div>
            ))}

            {/* 이메일 2단 분할 + 도메인 선택 */}
            <div className="form-group">
              <label>EMAIL</label>
              <div className="email-input-group">
                <input
                  type="text"
                  id="signup-email-id"
                  value={form.emailId}
                  onChange={(e) => handleChange("emailId", e.target.value)}
                  required
                  placeholder="Email ID"
                  className="email-id-input"
                />
                <span className="at-symbol">@</span>

                <input
                  type="text"
                  id="signup-email-domain-input"
                  value={form.emailDomain}
                  onChange={(e) => handleChange("emailDomain", e.target.value)}
                  required
                  placeholder="Input domain"
                  disabled={
                    domainOptions.includes(form.emailDomain) &&
                    form.emailDomain !== "ENTER MANUALLY"
                  }
                  className="email-domain-input"
                />

                <select
                  id="signup-email-domain-select"
                  onChange={handleDomainChange}
                  value={
                    domainOptions.includes(form.emailDomain)
                      ? form.emailDomain
                      : "ENTER MANUALLY"
                  }
                  className="email-domain-select"
                >
                  {domainOptions.map((domain) => (
                    <option key={domain} value={domain}>
                      {domain}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* 지역 선택 */}
            <div className="form-group">
              <label htmlFor="signup-region">REGION YOU LIVE IN</label>
              <select
                id="signup-region"
                value={form.region}
                onChange={(e) => handleChange("region", e.target.value)}
                required
              >
                <option value="">SELECT REGION</option>
                {regionOptions.map((region) => (
                  <option key={region} value={region}>
                    {region}
                  </option>
                ))}
              </select>
            </div>

            <button type="submit" className="signup-button">
              Create account
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
